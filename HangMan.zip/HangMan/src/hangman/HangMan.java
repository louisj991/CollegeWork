package hangman;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author ls181411
 */
public class HangMan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        Random num1 = new Random();
        int r1 = num1.nextInt(10);
        String[] words = new String[]{"eggs", "coffee", "string", "random", "number", "hangman", "score", "correct", "input", "repeat"};

        String Cword = words[r1];
        List<String> lettersguessed = new ArrayList<String>();

        boolean repeat = true;
        while (repeat = true) {
            int man = 0;

            System.out.println("Please guess a letter");
            String guess1 = input.next();
            lettersguessed.add(guess1);

            if (Cword.contains(guess1)) {
                System.out.println("well done the word contains the letter " + guess1);
                System.out.println("you have guessed the following letters" + lettersguessed);

            } else {
                System.out.println("The Word does not contain the letter " + guess1);

                man = man + 1;
            }

            if (man == 0) {
                System.out.println("_____");
                System.out.println("|    ");
                System.out.println("|    ");
                System.out.println("|    ");
                System.out.println("|    ");
            }
            if (man == 1) {
                System.out.println("______ ");
                System.out.println("|  |  ");
                System.out.println("|     ");
                System.out.println("|     ");
                System.out.println("|     ");
            }
            if (man == 2) {
                System.out.println("______ ");
                System.out.println("|  |  ");
                System.out.println("|  0   ");
                System.out.println("|     ");
                System.out.println("|     ");
            }

            if (man == 3) {
                System.out.println("______ ");
                System.out.println("|  |  ");
                System.out.println("|  0   ");
                System.out.println("|  |   ");
                System.out.println("|     ");
            }

            if (man == 4) {
                System.out.println("______ ");
                System.out.println("|  |  ");
                System.out.println("|  0   ");
                System.out.println("| /|   ");
                System.out.println("|     ");
            }

            if (man == 5) {
                System.out.println("______ ");
                System.out.println("|  |  ");
                System.out.println("|  0   ");
                System.out.println("| /|\\   ");
                System.out.println("|     ");
            }
            if (man == 6) {
                System.out.println("______ ");
                System.out.println("|  |  ");
                System.out.println("|  0   ");
                System.out.println("| /|\\   ");
                System.out.println("| /   ");
            }
            if (man == 7) {
                System.out.println("______ ");
                System.out.println("|  |  ");
                System.out.println("|  0   ");
                System.out.println("| /|\\   ");
                System.out.println("| / \\   ");
                System.out.println("You are out of guesses please enter the word");

            }
            String Fguess1 = input.next();

            System.out.println("do you want to guess the word");
            String mango = input.next();

            if (mango.equalsIgnoreCase("yes")) {
                System.out.println("Please enter your guess for the final word");
                String Fguess = input.next();

                if (Fguess.equalsIgnoreCase(Cword)) {
                    System.out.println("That is the correct word well done!");
                    System.out.println("do you want to play again?");
                    String again = input.next();

                    if (again.equalsIgnoreCase("no")) {
                        break;

                    } else {
                        System.out.println("That was not the correct word the word was " + Cword);
                        System.out.println("do you want to play again?");
                        String again2 = input.next();

                        if (again2.equalsIgnoreCase("no")) {
                            break;

                        }

                    }
                }

            }

            if (Fguess1.equalsIgnoreCase(Cword)) {
                System.out.println("Well done you guessed the word!");
                System.out.println("do you want to play again?");
            } else {
                    System.out.println("That was not the correct word the word was " + Cword);
            }

            String again3 = input.next();

            if (again3.equalsIgnoreCase("no")) {
                break;
            }

        }
    }
}
